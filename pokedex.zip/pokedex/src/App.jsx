import './App.css';
import Pokedex from './components/Pokedex/Pokedex';
function App() {
  
  return (
    <>
     <Pokedex />
    </>
  )
}

export default App
